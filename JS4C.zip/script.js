dogSentence = "Dogs are the bane of my existence"

var dogSentence = "Dogs are the bane of my existence"
dogSentence.replace ('Dogs' , 'Cats')

function makeMoreExciting(string) {
  return string + '!!!!'
}

var sentence = "time for a nap"
sentence = makeMoreExciting(sentence)

function yellIt(string) {
  string = string.toUpperCase()
  string = makeMoreExciting(string)
  console.log(string)
}

function yellIt(string) {
  string = string.toUpperCase()
  return makeMoreExciting(string)
}

console.log(yellIt("i fear no human"))

function logANumber(someNumber) {
  console.log(someNumber)
}
_.times(10, logANumber)

logANumber(0)
logANumber(1)
logANumber(2)
logANumber(3)
logANumber(4)
logANumber(5)
logANumber(6)
logANumber(7)
logANumber(8)
logANumber(9)

var zeroThroughTen = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

var myCatFriends = ["bill", "tabby", "ceiling"]

console.log(myCatFriends[0])

myCatFriends.push("super hip cat")

myCatFriends.length

var myCatFriends = ["bill", "tabby", "ceiling"]
var lastNames = ["the cat", "cat", "cat"]
var addresses = ["The Alley", "Grandmas House", "Attic"]

var firstCat = { name: "bill", lastName: "the cat", address: "The Alley" }
var secondCat = { name: "tabby", lastName: "cat", address: "Grandmas House" }
var thirdCat = { name: "ceiling", lastName: "cat", address: "Attic" }

